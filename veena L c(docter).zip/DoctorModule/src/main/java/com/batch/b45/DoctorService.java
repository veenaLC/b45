package com.batch.b45;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
@Transactional
public class DoctorService 
{
	@Autowired
	private DoctorRepository repo;
 
 public List<Doctor> listAll() 
 {

	 return repo.findAll();
 }
 
 public void save(Doctor doctor) 
 {
	 repo.save(doctor);
 }
 
 public Doctor get(Long id) 
 {
	 return repo.findById(id).get();
 }
 
 public void delete(Long id) 
 {
	 repo.deleteById(id);
	 } 
 }
