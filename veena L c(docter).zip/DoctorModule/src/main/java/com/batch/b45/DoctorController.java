package com.batch.b45;

import java.util.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestController
public class DoctorController 
{
	@Autowired
	private DoctorService service;
 
//RESTful API methods for Retrieval operations
	@GetMapping("/doctors")
	public List<Doctor> list() 
	{
		return service.listAll();
	}
	@GetMapping("/doctors/{id}")
	public ResponseEntity<Doctor> get(@PathVariable Long id) 
	{
		try
		{
			Doctor doctor = service.get(id);
			return new ResponseEntity<Doctor>(doctor, HttpStatus.OK);
		} 
		catch (NoSuchElementException e) 
		{
			return new ResponseEntity<Doctor>(HttpStatus.NOT_FOUND);
		} 
}
// RESTful API method for Create operation
	@PostMapping("/admins")
	public void add(@RequestBody Doctor doctor) 
	{
		service.save(doctor);
	}

// RESTful API method for Update operation
	@PutMapping("/doctors/{id}")
	public ResponseEntity<?> update(@RequestBody Doctor doctor, @PathVariable Long id) 
	{
		try
		{
			Doctor existAdmin = service.get(id);
			service.save(doctor);
			return new ResponseEntity<>(HttpStatus.OK);
		} 
		catch (NoSuchElementException e) 
		{
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} 
}
// RESTful API method for Delete operation
	@DeleteMapping("/doctors/{id}")
	public void delete(@PathVariable Long id) 
	{
		service.delete(id);
	} 
}